import React, { useState } from 'react';

export default function Build() {
  const [activeTab, setActiveTab] = useState<'av' | 'modes'>('av');

  return (
    <div className="w-full">
      {/* BUILD HERO */}
      <section className="min-h-[calc(100svh-88px)] md:min-h-[calc(100vh-96px)] py-12 md:py-20 flex flex-col justify-center relative overflow-hidden bg-bg-dark border-b border-border-subtle">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_60%_at_70%_90%,rgba(195,163,116,0.07)_0%,transparent_65%),radial-gradient(ellipse_40%_30%_at_5%_10%,rgba(195,163,116,0.04)_0%,transparent_55%)] pointer-events-none"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto w-full px-6 lg:px-8">
          <span className="text-[10px] md:text-[11px] uppercase tracking-[0.15em] md:tracking-[0.2em] px-4 py-1.5 border border-border-subtle text-brand-gold font-medium rounded-full mb-10 inline-block">
            Build
          </span>
          <h1 className="text-5xl md:text-8xl lg:text-[120px] font-display leading-[0.85] tracking-tight mb-10 md:mb-12">
            The gateway for capital<br/>
            <em className="font-serif italic text-gradient-gold">that moves between<br/>two worlds.</em>
          </h1>
          <p className="text-lg md:text-xl lg:text-2xl font-light leading-relaxed max-w-4xl text-text-body">
            For US capital seeking Vietnam exposure. For Vietnamese founders ready for institutional backing. For operators serious about building something that crosses borders.
          </p>
        </div>
      </section>

      <div className="bg-bg-alt border-b border-border-subtle flex overflow-x-auto">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 w-full flex gap-8">
          <button 
            className={`font-sans text-[11px] uppercase tracking-[0.2em] font-semibold py-6 outline-none border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'av' 
                ? 'border-brand-gold text-brand-gold' 
                : 'border-transparent text-text-muted hover:text-white'
            }`}
            onClick={() => setActiveTab('av')}
          >
            Access Vietnam 2026
          </button>
          <button 
            className={`font-sans text-[11px] uppercase tracking-[0.2em] font-semibold py-6 outline-none border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'modes' 
                ? 'border-brand-gold text-brand-gold' 
                : 'border-transparent text-text-muted hover:text-white'
            }`}
            onClick={() => setActiveTab('modes')}
          >
            How We Work
          </button>
        </div>
      </div>

      {activeTab === 'av' && (
        <div id="build-av">
          <section className="py-16 md:py-24 bg-bg-dark border-b border-border-subtle">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 mb-16 items-center">
                <div>
                  <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-10">
                    A historic delegation.<br/>
                    <em className="font-serif italic text-gradient-gold">21 days. Three countries.<br/>One corridor opening.</em>
                  </h2>
                  <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-8">
                    Co-organized by 100B and the Greater Austin Asian Chamber of Commerce. Led by GAACC President and CEO Mark Duval, former President of AmCham China. The delegation brings senior government officials and business leaders from Austin, Houston, and Central Texas directly into Vietnam's top business and government circles.
                  </p>
                </div>

                <div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6 mb-10">
                    <div className="bg-bg-alt p-6 lg:p-8 rounded-3xl border border-border-subtle">
                      <div className="text-[48px] md:text-[56px] font-serif font-light text-gradient-gold leading-none mb-4">21</div>
                      <div className="text-base font-light text-text-body">Days across three countries</div>
                    </div>
                    <div className="bg-bg-alt p-8 lg:p-10 rounded-3xl border border-border-subtle">
                      <div className="text-[48px] md:text-[56px] font-serif font-light text-gradient-gold leading-none mb-4">15+</div>
                      <div className="text-base font-light text-text-body">Business and government delegates</div>
                    </div>
                    <div className="bg-bg-alt p-8 lg:p-10 rounded-3xl border border-border-subtle">
                      <div className="text-[48px] md:text-[56px] font-serif font-light text-gradient-gold leading-none mb-4">3</div>
                      <div className="text-base font-light text-text-body">Countries: Taiwan, Vietnam, Singapore</div>
                    </div>
                  </div>

                  <div className="bg-bg-card p-8 md:p-10 border border-brand-gold/20 rounded-3xl shadow-lg">
                    <div className="font-sans text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-8">The Route &mdash; May 30 to June 19, 2026</div>
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 relative z-10 w-full overflow-hidden">
                      {[ 
                        { city: 'Austin', date: 'May 30' },
                        { city: 'Taipei', date: 'May 31' },
                        { city: 'Hanoi', date: 'Jun 7', gold: true },
                        { city: 'HCM City', date: 'Jun 11', gold: true },
                        { city: 'Singapore', date: 'Jun 13' },
                        { city: 'Austin', date: 'Jun 19' }
                      ].map((stop, idx) => (
                        <div key={idx} className="flex md:flex-col items-center gap-4 md:gap-3 z-10 w-full md:w-auto relative">
                          {idx !== 0 && (
                            <div className="absolute left-[-15px] md:left-auto md:top-3 md:right-full md:mr-6 md:w-[60px] h-[30px] md:h-px border-l md:border-l-0 md:border-t border-border-subtle border-dashed"></div>
                          )}
                          <div className={`w-3.5 md:w-4 h-3.5 md:h-4 rounded-full flex-shrink-0 ${stop.gold ? 'bg-brand-gold shadow-[0_0_8px_rgba(196,152,42,0.6)]' : 'bg-white/30'}`}></div>
                          <div className="flex flex-col items-start md:items-center">
                            <div className={`font-serif text-xl md:text-2xl font-light ${stop.gold ? 'text-brand-gold' : 'text-white'}`}>{stop.city}</div>
                            <div className="font-sans text-[11px] text-text-muted tracking-[0.1em] mt-1.5 uppercase">{stop.date}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                <div className="bg-bg-card p-8 lg:p-10 rounded-3xl border border-border-subtle shadow-lg">
                  <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">01</div>
                  <p className="text-base md:text-lg text-text-body font-light leading-relaxed">Engage directly with Vietnam's top government organizations and business leaders &mdash; the relationships that take years to build independently.</p>
                </div>
                <div className="bg-bg-card p-8 lg:p-10 rounded-3xl border border-border-subtle shadow-lg">
                  <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">02</div>
                  <p className="text-base md:text-lg text-text-body font-light leading-relaxed">Strengthen diplomatic and economic ties between Vietnam and the cities of Austin and Houston &mdash; laying the groundwork for long-term investment flow.</p>
                </div>
                <div className="bg-bg-card p-8 lg:p-10 rounded-3xl border border-border-subtle shadow-lg">
                  <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">03</div>
                  <p className="text-base md:text-lg text-text-body font-light leading-relaxed">Explore concrete avenues for trade, investment, and business partnership in technology, advanced manufacturing, and creative industries.</p>
                </div>
              </div>

              <div className="text-center mt-12 md:mt-16">
                <p className="text-sm md:text-base text-text-muted mb-6 font-serif italic">Delegate list to be finalized by April 30, 2026.</p>
                <button className="bg-white hover:bg-brand-gold text-bg-dark hover:text-white rounded-full uppercase tracking-widest px-10 py-5 text-xs font-semibold transition-colors">
                  Request Delegation Information
                </button>
              </div>
            </div>
          </section>

          {/* AUSTIN AS DESTINATION */}
          <section className="py-16 md:py-24 bg-bg-alt border-b border-border-subtle">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
                <div>
                  <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-10">
                    Central Texas has become<br/>
                    <em className="font-serif italic text-gradient-gold">Asia's preferred destination<br/>for capital.</em>
                  </h2>
                  <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-8">
                    Driven by supply chain diversification and a global AI infrastructure supercycle, companies from Taiwan, Korea, Japan, Singapore, India, and Vietnam are aggressively investing in Central Texas.
                  </p>
                  <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-6">
                    The $37B Samsung Taylor expansion has catalyzed a regional clustering effect drawing hundreds of Tier 1 and 2 suppliers to the Austin-San Antonio corridor.
                  </p>
                </div>

                <div className="flex flex-col gap-6">
                  <div className="bg-bg-card p-6 md:p-8 rounded-3xl border border-border-subtle flex flex-col md:flex-row gap-6 md:gap-8 items-start hover:border-brand-gold/30 transition-colors shadow-lg">
                    <div className="font-serif text-[48px] md:text-[56px] font-light text-gradient-gold flex-shrink-0 leading-none">$37B</div>
                    <div className="text-base md:text-lg text-text-body font-light pt-2">Samsung Taylor expansion anchoring a regional tech manufacturing cluster</div>
                  </div>
                  <div className="bg-bg-card p-6 md:p-8 rounded-3xl border border-border-subtle flex flex-col md:flex-row gap-6 md:gap-8 items-start hover:border-brand-gold/30 transition-colors shadow-lg">
                    <div className="font-serif text-[48px] md:text-[56px] font-light text-gradient-gold flex-shrink-0 leading-none">6</div>
                    <div className="text-base md:text-lg text-text-body font-light pt-2">Asian nations actively investing in the Greater Austin region: Taiwan, Korea, Japan, Singapore, India, Vietnam</div>
                  </div>
                  <div className="bg-bg-card p-6 md:p-8 rounded-3xl border border-border-subtle flex flex-col md:flex-row gap-6 md:gap-8 items-start hover:border-brand-gold/30 transition-colors shadow-lg">
                    <div className="font-serif text-[48px] md:text-[56px] font-light text-gradient-gold flex-shrink-0 leading-none">100M</div>
                    <div className="text-base md:text-lg text-text-body font-light pt-2">Population in Vietnam's high-growth market &mdash; one of Southeast Asia's fastest expanding economies</div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}

      {activeTab === 'modes' && (
        <div id="build-modes">
          <section className="py-16 md:py-24 bg-bg-dark border-b border-border-subtle">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-10 max-w-4xl">
                Three modes.<br/>
                <em className="font-serif italic text-gradient-gold">Every deal fits one of them.</em>
              </h2>
              <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-16 max-w-3xl">
                If it does not fit, we pass. That selectivity is what makes the deals we take worth something.
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
                {/* Mode 1 */}
                <div className="relative p-8 lg:p-10 rounded-3xl bg-bg-card border border-border-subtle h-full flex flex-col group hover:border-brand-gold/50 transition-colors shadow-lg">
                  <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">01</div>
                  <div className="text-[11px] md:text-xs uppercase tracking-[0.2em] font-semibold text-brand-gold mb-4">Build</div>
                  <h3 className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-6 leading-tight">Co-build US brands with Vietnamese manufacturers</h3>
                  <p className="text-base lg:text-lg text-text-body font-light leading-relaxed flex-grow">
                    OEM-ready factories with zero US brand presence. We bring brand, sales infrastructure, and market access. We own the US-facing entity together.
                  </p>
                  <div className="mt-10 pt-8 border-t border-border-subtle flex flex-col gap-4">
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Starting focus: construction and finish materials</div>
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Target partners: $30M-$200M+ annual revenue</div>
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Structure: shared equity in US brand entity</div>
                  </div>
                </div>

                {/* Mode 2 */}
                <div className="relative p-8 lg:p-10 rounded-3xl bg-bg-card border border-border-subtle h-full flex flex-col group hover:border-brand-gold/50 transition-colors shadow-lg">
                  <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">02</div>
                  <div className="text-[11px] md:text-xs uppercase tracking-[0.2em] font-semibold text-brand-gold mb-4">Accelerate</div>
                  <h3 className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-6 leading-tight">Come in as the operating partner</h3>
                  <p className="text-base lg:text-lg text-text-body font-light leading-relaxed flex-grow">
                    We identify the 5-10% of gaps causing 80% of the drag. Redesign the workflow. Stay through execution. We take equity &mdash; not just consulting fees.
                  </p>
                  <div className="mt-10 pt-8 border-t border-border-subtle flex flex-col gap-4">
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Equity stake: 3% to 20% depending on scope</div>
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Target: $5M+ revenue businesses, any industry</div>
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Cash retainer negotiated alongside equity</div>
                  </div>
                </div>

                {/* Mode 3 */}
                <div className="relative p-8 lg:p-10 rounded-3xl bg-bg-card border border-border-subtle h-full flex flex-col group hover:border-brand-gold/50 transition-colors shadow-lg">
                  <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">03</div>
                  <div className="text-[11px] md:text-xs uppercase tracking-[0.2em] font-semibold text-brand-gold mb-4">Connect</div>
                  <h3 className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-6 leading-tight">Bridge capital across the corridor</h3>
                  <p className="text-base lg:text-lg text-text-body font-light leading-relaxed flex-grow">
                    Capital, founders, and operators move in both directions across this corridor. We are the trusted introduction on either side &mdash; because we are already in both rooms.
                  </p>
                  <div className="mt-10 pt-8 border-t border-border-subtle flex flex-col gap-4">
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Deal fees: 3-5% of capital or transaction value</div>
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Advisory: board seats, 1-5% equity stakes</div>
                    <div className="text-base text-text-body font-light flex gap-3"><span className="text-brand-gold font-serif">—</span>Fastest path to revenue of the three modes</div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
