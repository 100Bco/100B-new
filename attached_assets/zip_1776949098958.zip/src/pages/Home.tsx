import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';
import { FoundersCarousel } from '../components/FoundersCarousel';
import { WhyVietnam } from '../components/WhyVietnam';

export default function Home() {
  return (
    <div className="w-full">
      {/* HERO */}
      <section className="min-h-[calc(100svh-88px)] md:min-h-[calc(100vh-96px)] py-12 md:py-20 flex flex-col justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_60%_80%,rgba(195,163,116,0.05)_0%,transparent_65%),radial-gradient(ellipse_50%_40%_at_10%_20%,rgba(195,163,116,0.03)_0%,transparent_55%)] pointer-events-none"></div>
        <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent,transparent_119px,rgba(255,255,255,0.025)_119px,rgba(255,255,255,0.025)_120px)] pointer-events-none"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto w-full px-6 lg:px-8">
          <span className="text-[10px] md:text-[11px] uppercase tracking-[0.15em] md:tracking-[0.2em] px-4 py-1.5 border border-border-subtle text-brand-gold font-medium rounded-full mb-10 inline-block">
            Cross-Border Capital & Brand Platform
          </span>
          
          <h1 className="text-5xl md:text-8xl lg:text-[120px] font-display leading-[0.85] tracking-tight mb-10 md:mb-12">
            The operating partner<br/>for serious deals<br/>
            <em className="font-serif italic text-gradient-gold">between two worlds.</em>
          </h1>

          <p className="text-lg md:text-xl lg:text-2xl font-light leading-relaxed max-w-4xl mb-14 md:mb-16 text-text-body">
            We connect elite operators, capital, and builders across the US-Vietnam corridor. The deals worth doing are getting bigger and more complex. We are in those rooms.
          </p>

          <div className="flex flex-wrap gap-5 items-center">
            <Link to="/build" className="px-10 py-5 btn-silver-gradient rounded-full text-xs uppercase tracking-widest font-semibold flex items-center gap-2 group">
              Explore Build
              <ArrowRight className="group-hover:translate-x-1 transition-transform" size={16} />
            </Link>
            <Link to="/trade" className="bg-white hover:bg-brand-gold text-bg-dark hover:text-white rounded-full uppercase tracking-widest px-10 py-5 text-xs font-semibold transition-colors flex items-center gap-2 group border border-transparent">
              Explore Trade
              <ArrowRight className="group-hover:translate-x-1 transition-transform text-bg-dark group-hover:text-white" size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* WHY VIETNAM SECTION */}
      <WhyVietnam />

      {/* MODES SECTION */}
      <section className="py-16 md:py-24 bg-bg-alt border-y border-border-subtle">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-12 max-w-4xl">
            Three ways 100B<br/>
            <em className="font-serif italic text-gradient-gold">builds with you.</em>
          </h2>
          
          <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed max-w-4xl mb-12 md:mb-16">
            Every deal we take fits one of these three modes. If it does not fit any of them, we pass.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 lg:gap-8">
            {/* Mode 1 */}
            <div className="bg-bg-card rounded-3xl p-8 lg:p-10 flex flex-col shadow-lg border border-border-subtle hover:bg-bg-card-hover hover:border-brand-gold/50 transition-colors">
              <div className="text-[40px] md:text-[48px] lg:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">01</div>
              <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-3">Build</div>
              <h3 className="text-xl lg:text-2xl font-bold font-sans text-text-heading mb-6 leading-tight">Co-build brands from scratch</h3>
              <p className="text-base font-light text-text-body leading-relaxed flex-grow">
                We partner with Vietnamese manufacturers who are OEM-ready but have zero US brand presence. We bring the brand, sales infrastructure, and market access. They bring decades of manufacturing expertise. We own the US-facing brand together.
              </p>
            </div>

            {/* Mode 2 */}
            <div className="bg-bg-card rounded-3xl p-8 lg:p-10 flex flex-col shadow-lg border border-border-subtle hover:bg-bg-card-hover hover:border-brand-gold/50 transition-colors">
              <div className="text-[40px] md:text-[48px] lg:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">02</div>
              <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-3">Accelerate</div>
              <h3 className="text-xl lg:text-2xl font-bold font-sans text-text-heading mb-6 leading-tight">Come in as the operating partner</h3>
              <p className="text-base font-light text-text-body leading-relaxed flex-grow">
                We walk into existing businesses, identify the 5-10% of gaps causing 80% of the drag, redesign the workflow, and stay through execution. We take an equity stake and we build alongside you.
              </p>
            </div>

            {/* Mode 3 */}
            <div className="bg-bg-card rounded-3xl p-8 lg:p-10 flex flex-col shadow-lg border border-border-subtle hover:bg-bg-card-hover hover:border-brand-gold/50 transition-colors">
              <div className="text-[40px] md:text-[48px] lg:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">03</div>
              <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-3">Connect</div>
              <h3 className="text-xl lg:text-2xl font-bold font-sans text-text-heading mb-6 leading-tight">Bridge capital across borders</h3>
              <p className="text-base font-light text-text-body leading-relaxed flex-grow">
                Capital, founders, and operators move in both directions across this corridor. We are the trusted introduction on either side &mdash; because we are already in both rooms.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* BUCKETS SECTION */}
      <section className="py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light leading-tight mb-8 md:mb-12 max-w-4xl">
            Two platforms.<br/>
            <em className="font-serif italic text-gradient-gold">One corridor.</em>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 min-h-[500px]">
            {/* Trade Bucket */}
            <div className="bg-gold-gradient rounded-3xl p-8 lg:p-10 flex flex-col shadow-xl text-black">
              <div className="text-[11px] md:text-xs uppercase tracking-[0.2em] font-semibold text-black/60 mb-6">Trade</div>
              <h3 className="text-3xl md:text-4xl lg:text-4xl font-serif font-serif font-medium text-black mb-4 leading-tight">Direct-to-factory sourcing across Asia</h3>
              <p className="text-base lg:text-lg font-medium leading-relaxed mb-8 text-black/80 flex-grow">
                For GCs, developers, and architects who are done paying 3-4x factory price through domestic distributors. We organize direct sourcing delegations and maintain the vetted network that makes it work.
              </p>
              
              <div className="flex flex-col gap-0 border-y border-black/10 mb-8">
                <Link to="/trade" className="flex justify-between items-center py-4 border-b border-black/10 group">
                  <span className="text-base font-semibold text-black/90 group-hover:text-black transition-colors">Build Better Series</span>
                  <ArrowRight size={20} className="text-black group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link to="/trade" className="flex justify-between items-center py-4 border-b border-black/10 group">
                  <span className="text-base font-semibold text-black/90 group-hover:text-black transition-colors">Vietnam Direct 2026</span>
                  <ArrowRight size={20} className="text-black group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link to="/cc" className="flex justify-between items-center py-4 group">
                  <span className="text-base font-semibold text-black/90 group-hover:text-black transition-colors">Container Club</span>
                  <ArrowRight size={20} className="text-black group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>

              <Link to="/trade" className="self-start text-xs uppercase tracking-widest font-semibold px-8 py-4 border border-black hover:bg-black hover:text-brand-gold rounded-full transition-colors inline-flex items-center gap-3 group">
                Explore Trade
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            {/* Build Bucket */}
            <div className="bg-silver-gradient rounded-3xl p-8 lg:p-10 flex flex-col shadow-xl text-black">
              <div className="text-[11px] md:text-xs uppercase tracking-[0.2em] font-semibold text-black/60 mb-6">Build</div>
              <h3 className="text-3xl md:text-4xl lg:text-4xl font-serif font-medium text-black mb-4 leading-tight">Capital and partnerships across borders</h3>
              <p className="text-base lg:text-lg font-medium leading-relaxed mb-8 text-black/80 flex-grow">
                For capital seeking Vietnam exposure, founders ready to go global, and operators serious about building something that lasts. We are the trusted gateway between Austin and Hanoi &mdash; and everything in between.
              </p>
              
              <div className="flex flex-col gap-0 border-y border-black/10 mb-8">
                <Link to="/build" className="flex justify-between items-center py-4 border-b border-black/10 group">
                  <span className="text-base font-semibold text-black/90 group-hover:text-black transition-colors">Access Vietnam 2026</span>
                  <ArrowRight size={20} className="text-black group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link to="/build" className="flex justify-between items-center py-4 border-b border-black/10 group">
                  <span className="text-base font-semibold text-black/90 group-hover:text-black transition-colors">Advisory & Equity Stakes</span>
                  <ArrowRight size={20} className="text-black group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link to="/build" className="flex justify-between items-center py-4 group">
                  <span className="text-base font-semibold text-black/90 group-hover:text-black transition-colors">Cross-Border Deal Flow</span>
                  <ArrowRight size={20} className="text-black group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>

              <Link to="/build" className="self-start text-xs uppercase tracking-widest font-semibold px-8 py-4 border border-black hover:bg-black hover:text-white rounded-full inline-flex items-center gap-3 transition-colors group">
                Explore Build
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* WHY US - EDITORIAL STYLE */}
      <section className="py-20 md:py-32 bg-bg-main border-b border-border-subtle">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-8">
          
          <div className="flex flex-col gap-16 lg:gap-20">
            {/* Top Row: Big Headline & Intro & Stats */}
            <div>
              <div className="max-w-4xl">
                <div className="text-xs font-mono uppercase tracking-[0.2em] text-brand-gold mb-8">The Moat</div>
                <h2 className="text-4xl md:text-5xl lg:text-[64px] font-serif font-light leading-[1.1] tracking-tight mb-8">
                  One person fluent in <em className="italic text-gradient-gold">both worlds.</em>
                </h2>
                <div className="w-12 h-[1px] bg-brand-gold mb-8"></div>
                <p className="text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-12">
                  Minh Mac left Vietnam at 17. Spent a decade building across the US &mdash; private equity covering a $65B portfolio, real estate, and a 1.6M-user tech startup in SEA. This cross-border identity opens rooms in both markets that most can only access from one side.
                </p>
                
                {/* Stats */}
                <div className="flex flex-row gap-12 md:gap-24 pt-8 border-t border-border-subtle">
                   <div>
                     <div className="text-3xl md:text-4xl lg:text-5xl font-serif text-text-heading mb-2"><span className="text-brand-gold">$</span>65B</div>
                     <div className="text-xs font-mono uppercase tracking-widest text-text-muted">AUM Coverage</div>
                   </div>
                   <div>
                     <div className="text-3xl md:text-4xl lg:text-5xl font-serif text-text-heading mb-2">1.6M</div>
                     <div className="text-xs font-mono uppercase tracking-widest text-text-muted">Startup Users</div>
                   </div>
                </div>
              </div>
            </div>

            {/* Bottom Row: 4 Cards */}
            <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4 lg:gap-6">
              
              {/* Card 1 */}
              <div className="bg-[#111111] p-6 lg:p-8 rounded-2xl relative overflow-hidden flex flex-col min-h-[220px] transition-transform duration-500 hover:-translate-y-1">
                <div className="relative z-10 flex flex-col h-full">
                  <h3 className="text-xl lg:text-2xl font-serif italic text-gradient-gold mb-8 uppercase tracking-wide">
                    Private Equity Lens
                  </h3>
                  <div className="flex flex-col gap-4 text-sm font-light text-white/80 mt-auto">
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Institutional deal structuring</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Leverage & risk modeling</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Clear exit timelines</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Card 2 */}
              <div className="bg-[#111111] p-6 lg:p-8 rounded-2xl relative overflow-hidden flex flex-col min-h-[220px] transition-transform duration-500 hover:-translate-y-1">
                <div className="relative z-10 flex flex-col h-full">
                  <h3 className="text-xl lg:text-2xl font-serif italic text-gradient-gold mb-8 uppercase tracking-wide">
                    Operator Record
                  </h3>
                  <div className="flex flex-col gap-4 text-sm font-light text-white/80 mt-auto">
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Hands-on business building</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Agency vetting & replacement</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Go-to-market execution</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card 3 */}
              <div className="bg-[#111111] p-6 lg:p-8 rounded-2xl relative overflow-hidden flex flex-col min-h-[220px] transition-transform duration-500 hover:-translate-y-1">
                <div className="relative z-10 flex flex-col h-full">
                  <h3 className="text-xl lg:text-2xl font-serif italic text-gradient-gold mb-8 uppercase tracking-wide">
                    In Both Rooms
                  </h3>
                  <div className="flex flex-col gap-4 text-sm font-light text-white/80 mt-auto">
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Austin local boardrooms</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Hanoi business networks</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Immediate trust bridges</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card 4 */}
              <div className="bg-[#111111] p-6 lg:p-8 rounded-2xl relative overflow-hidden flex flex-col min-h-[220px] transition-transform duration-500 hover:-translate-y-1">
                <div className="relative z-10 flex flex-col h-full">
                  <h3 className="text-xl lg:text-2xl font-serif italic text-gradient-gold mb-8 uppercase tracking-wide">
                    Selective By Design
                  </h3>
                  <div className="flex flex-col gap-4 text-sm font-light text-white/80 mt-auto">
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>High rejection rate</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Strict 100B fit criteria</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-silver-gradient flex items-center justify-center shrink-0 mt-0.5 shadow-sm border border-white/20">
                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 4L3.5 6.5L9 1" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                      <span>Preserved partner value</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <FoundersCarousel />
    </div>
  );
}
