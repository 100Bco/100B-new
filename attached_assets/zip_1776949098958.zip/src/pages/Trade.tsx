import React, { useState } from 'react';

export default function Trade() {
  const [activeTab, setActiveTab] = useState<'bbs'>('bbs');

  return (
    <div className="w-full">
      {/* TRADE HERO */}
      <section className="min-h-[calc(100svh-88px)] md:min-h-[calc(100vh-96px)] py-12 md:py-20 flex flex-col justify-center relative overflow-hidden bg-bg-dark border-b border-border-subtle">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_80%_20%,rgba(195,163,116,0.06)_0%,transparent_65%),radial-gradient(ellipse_40%_40%_at_20%_80%,rgba(195,163,116,0.04)_0%,transparent_55%)] pointer-events-none"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto w-full px-6 lg:px-8">
           <span className="text-[10px] md:text-[11px] uppercase tracking-[0.15em] md:tracking-[0.2em] px-4 py-1.5 border border-border-subtle text-brand-gold font-medium rounded-full mb-10 inline-block">
            Trade
          </span>
          <h1 className="text-5xl md:text-8xl lg:text-[120px] font-display leading-[0.85] tracking-tight mb-10 md:mb-12">
            Direct to factory.<br/>
            <em className="font-serif italic text-gradient-gold">No markup.<br/>No middleman.</em>
          </h1>
          <p className="text-lg md:text-xl lg:text-2xl font-light leading-relaxed max-w-4xl text-text-body">
            We organize direct-sourcing delegations and maintain the vetted trade network for builders who are serious about controlling material costs.
          </p>
        </div>
      </section>

      <div className="bg-bg-alt border-b border-border-subtle flex overflow-x-auto">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 w-full flex">
          <button 
            className={`font-sans text-[11px] uppercase tracking-[0.2em] font-semibold py-6 outline-none border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'bbs' 
                ? 'border-brand-gold text-brand-gold' 
                : 'border-transparent text-text-muted hover:text-white'
            }`}
            onClick={() => setActiveTab('bbs')}
          >
            Build Better Series
          </button>
        </div>
      </div>

      {activeTab === 'bbs' && (
        <div id="trade-bbs">
          {/* BBS HERO */}
          <section className="py-16 md:py-24 bg-bg-dark border-b border-border-subtle">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-start">
                <div>
                  <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-10">
                    The sourcing delegation<br/>series for serious <em className="font-serif italic text-gradient-gold">builders.</em>
                  </h2>
                  <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-8">
                    The Build Better Series is 100B's ongoing program bringing US-based GCs, developers, and architects directly to Asian factories. No distributors. No markups. No guessing. You see the factory floor, meet the operators, and build the relationship that makes direct sourcing actually work.
                  </p>
                  <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed">
                    Vietnam is the first chapter. The series expands as the network grows.
                  </p>
                </div>
                
                <div className="bg-bg-alt p-8 lg:p-10 border border-brand-gold/30 rounded-3xl relative overflow-hidden group shadow-lg">
                  <div className="font-sans text-[11px] uppercase tracking-[0.2em] text-brand-gold mb-6 font-semibold">Why This Works</div>
                  <div className="flex flex-col gap-6">
                    <div className="flex gap-4">
                      <div className="text-brand-gold flex-shrink-0">—</div>
                      <div className="text-sm lg:text-base text-text-body font-light leading-relaxed">Materials are 25-35% of total construction cost. You are paying 3-4x factory price through domestic distributors.</div>
                    </div>
                    <div className="flex gap-4">
                      <div className="text-brand-gold flex-shrink-0">—</div>
                      <div className="text-sm lg:text-base text-text-body font-light leading-relaxed">Vietnam's construction and finishing material exports reached $17.5B in 2024 and are growing.</div>
                    </div>
                    <div className="flex gap-4">
                      <div className="text-brand-gold flex-shrink-0">—</div>
                      <div className="text-sm lg:text-base text-text-body font-light leading-relaxed">Every factory in our program is pre-vetted. You visit knowing it is already approved.</div>
                    </div>
                    <div className="flex gap-4">
                      <div className="text-brand-gold flex-shrink-0">—</div>
                      <div className="text-sm lg:text-base text-text-body font-light leading-relaxed">20-25% savings going direct vs. domestic distribution. On a $5M project, that is $250K-$500K back in margin.</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mt-16">
                <div className="relative p-8 lg:p-10 rounded-3xl bg-bg-card border border-brand-gold/40 flex flex-col group hover:border-brand-gold/80 transition-colors shadow-lg">
                  <div className="absolute top-8 right-10 text-6xl md:text-[80px] font-display font-light text-brand-gold/10 leading-none">2026</div>
                  <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-6 relative z-10">Active — May 30 to June 5, 2026</div>
                  <h3 className="text-3xl lg:text-4xl font-serif font-normal text-text-heading mb-6 relative z-10">Vietnam Direct 2026</h3>
                  <p className="text-base lg:text-lg text-text-body font-light leading-relaxed flex-grow relative z-10 mb-10">
                    Ho Chi Minh City to Hanoi. 7 days. 10+ vetted factories across construction and finishing materials &mdash; engineered wood, aluminum windows, steel structures, porcelain tile, composite panels and more. By invitation only.
                  </p>
                  <button className="btn-silver-gradient rounded-full px-8 py-4 uppercase tracking-widest text-xs self-start font-semibold">
                    Request an Invite
                  </button>
                </div>
                
                <div className="relative p-8 lg:p-10 rounded-3xl bg-bg-alt border border-border-subtle border-dashed flex flex-col opacity-70 hover:opacity-100 hover:border-brand-gold/30 transition-all">
                  <div className="absolute top-8 right-10 text-6xl md:text-[80px] font-display font-light text-white/5 leading-none">2027</div>
                  <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-text-muted mb-6 relative z-10">Coming 2027</div>
                  <h3 className="text-3xl lg:text-4xl font-serif font-normal text-text-heading mb-6 relative z-10">Next Chapter — Asia</h3>
                  <p className="text-base lg:text-lg text-text-body font-light leading-relaxed flex-grow relative z-10 mb-10">
                    The Build Better Series continues. Location to be announced. If you want to be on the early list when the next trip opens, get in touch now.
                  </p>
                  <button className="bg-transparent text-brand-gold border border-brand-gold/30 hover:border-brand-gold hover:bg-brand-gold/5 rounded-full px-8 py-4 uppercase tracking-widest text-xs transition-colors font-semibold self-start">
                    Join the Waitlist
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* VIETNAM DIRECT DETAIL */}
          <section className="py-16 md:py-24 bg-bg-alt border-b border-border-subtle">
            <div className="max-w-7xl mx-auto px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
                <div>
                  <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-10">
                    7 days. 10+ factories.<br/>
                    <em className="font-serif italic text-gradient-gold">One trip that changes your margins forever.</em>
                  </h2>
                  <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-12">
                    Co-hosted by Minh Mac (100B) and Lezlie Tram (LT Commercial Group). Designed specifically for Austin-area GCs, developers, and architects who are ready to build a direct supply chain in Vietnam.
                  </p>

                  <div className="grid grid-cols-2 gap-4 lg:gap-6">
                    <div className="bg-bg-card p-6 lg:p-8 rounded-2xl border border-brand-gold/20 shadow-lg">
                      <div className="text-[48px] md:text-[56px] font-serif font-light text-gradient-gold leading-none mb-4">20-25%</div>
                      <div className="text-base font-light text-text-body">Savings vs. domestic distribution</div>
                    </div>
                    <div className="bg-bg-card p-8 lg:p-10 rounded-2xl border border-brand-gold/20 shadow-lg">
                      <div className="text-[48px] md:text-[56px] font-serif font-light text-gradient-gold leading-none mb-4">10+</div>
                      <div className="text-base font-light text-text-body">Pre-vetted factory partners</div>
                    </div>
                    <div className="bg-bg-card p-8 lg:p-10 rounded-2xl border border-brand-gold/20 shadow-lg">
                      <div className="text-[48px] md:text-[56px] font-serif font-light text-gradient-gold leading-none mb-4">D2C</div>
                      <div className="text-base font-light text-text-body">Factory to job site. No markup.</div>
                    </div>
                    <div className="bg-bg-card p-8 lg:p-10 rounded-2xl border border-brand-gold/20 shadow-lg">
                      <div className="text-[48px] md:text-[56px] font-serif font-light text-gradient-gold leading-none mb-4">7</div>
                      <div className="text-base font-light text-text-body">Days. HCM City to Hanoi.</div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-6">
                  <div className="font-sans text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-2">Factory Categories</div>
                  {[
                    { kind: 'Engineered Wood & Panels', specific: 'An Cuong · Phu Tai' },
                    { kind: 'Aluminum Windows & Doors', specific: 'BM Windows · Eurowindow' },
                    { kind: 'Steel Structures', specific: 'Dai Dung · Hoa Phat' },
                    { kind: 'Composite & Surface Materials', specific: 'Tonmat · AA Corp' },
                    { kind: 'Packaging & Bioplastics', specific: 'An Phat Holdings' },
                    { kind: 'Furniture & Interiors', specific: 'Amy Grupo' }
                  ].map((cat, idx) => (
                    <div key={idx} className="bg-bg-card p-6 md:p-8 flex flex-col md:flex-row justify-between md:items-center gap-2 border border-border-subtle rounded-2xl group hover:border-brand-gold/50 transition-colors">
                      <span className="text-lg font-light text-text-heading">{cat.kind}</span>
                      <span className="text-[11px] font-sans font-semibold text-brand-gold uppercase tracking-wider">{cat.specific}</span>
                    </div>
                  ))}
                  
                  <div className="mt-12 flex justify-center lg:justify-start">
                    <button className="btn-silver-gradient w-full lg:w-auto px-12 py-5 rounded-full uppercase tracking-widest text-xs font-bold text-center">
                      Request an Invite to Vietnam Direct 2026
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
