import React from 'react';
import { Link } from 'react-router-dom';

export default function ContainerClub() {
  return (
    <div className="w-full">
      {/* CC HERO */}
      <section className="min-h-[calc(100svh-88px)] md:min-h-[calc(100vh-96px)] py-12 md:py-20 flex flex-col justify-center relative overflow-hidden bg-bg-dark border-b border-border-subtle">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_70%_at_50%_100%,rgba(195,163,116,0.06)_0%,transparent_65%)] pointer-events-none"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto w-full px-6 lg:px-8">
          <span className="text-[10px] md:text-[11px] uppercase tracking-[0.15em] md:tracking-[0.2em] px-4 py-1.5 border border-border-subtle text-brand-gold font-medium rounded-full mb-10 inline-block">
            Container Club
          </span>
          <h1 className="text-5xl md:text-8xl lg:text-[120px] font-display leading-[0.85] tracking-tight mb-10 md:mb-12">
            The private network for<br/>people who actually<br/>
            <em className="font-serif italic text-gradient-gold">move goods.</em>
          </h1>
          <p className="text-lg md:text-xl lg:text-2xl font-light leading-relaxed max-w-4xl text-text-body">
            Everyone involved in cross-border trade &mdash; in one vetted network. By introduction only.
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-bg-alt border-b border-border-subtle">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-10">
                Not a directory.<br/>
                <em className="font-serif italic text-gradient-gold">A network of people<br/>who actually deliver.</em>
              </h2>
              <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-8">
                International trade has a trust problem. Finding a freight vendor who actually shows up, a customs broker who actually knows the regulations, a buyer who actually pays &mdash; it requires relationships that take years to build.
              </p>
              <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-8">
                Container Club is 100B's vetted private network of everyone who makes cross-border trade work. Every member is introduced, not applied. Every member has a track record.
              </p>
              <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-12">
                More details on membership coming soon. If you want to be on the early list, reach out directly.
              </p>
              
              <div className="flex flex-wrap gap-4 items-center">
                <a href="mailto:global@100b.co" className="btn-silver-gradient rounded-full px-10 py-5 uppercase tracking-widest text-xs font-semibold">
                  Express Interest
                </a>
                <Link to="/trade" className="bg-transparent text-brand-gold border border-brand-gold/30 hover:border-brand-gold hover:bg-brand-gold/5 rounded-full px-10 py-5 uppercase tracking-widest text-xs transition-colors font-semibold">
                  Back to Trade
                </Link>
              </div>
            </div>

            <div className="w-full">
              <div className="bg-bg-alt border border-brand-gold/30 p-8 md:p-12 lg:p-14 relative overflow-hidden rounded-3xl group hover:border-brand-gold/50 transition-colors shadow-lg">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_60%,rgba(195,163,116,0.08)_0%,transparent_60%)] pointer-events-none"></div>
                
                <div className="relative z-10">
                  <div className="font-serif text-5xl md:text-6xl font-light text-text-heading mb-6">
                    Container <span className="text-brand-gold italic">Club</span>
                  </div>
                  <div className="font-sans text-[11px] md:text-xs uppercase tracking-[0.2em] font-semibold text-text-muted mb-12">
                    A 100B Network &middot; By Introduction Only
                  </div>
                  
                  <div className="flex flex-col gap-4">
                    {[
                      'Freight vendors and forwarders',
                      'Licensed customs brokers',
                      'Verified buyers and importers',
                      'Factory representatives',
                      'Trade finance specialists',
                      'Compliance and logistics advisors'
                    ].map((item, idx) => (
                      <div key={idx} className="bg-bg-card p-5 md:p-6 flex items-center gap-4 rounded-xl border border-border-subtle group-hover:border-brand-gold/30 transition-colors">
                        <div className="w-2 h-2 bg-brand-gold rounded-full flex-shrink-0"></div>
                        <div className="text-base md:text-lg text-text-body font-light leading-none">{item}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-bg-dark border-b border-border-subtle">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-16 max-w-4xl">
            The people who make trade work<br/>
            <em className="font-serif italic text-gradient-gold">deserve a room of their own.</em>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            <div className="bg-bg-card p-8 lg:p-10 rounded-3xl h-full border border-border-subtle hover:bg-bg-card-hover hover:border-brand-gold/50 transition-colors shadow-lg">
              <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">01</div>
              <h3 className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-6">Vetted, not listed</h3>
              <p className="text-base lg:text-lg text-text-body font-light leading-relaxed">
                Every member is introduced by someone already in the network. No cold applications. No unverified profiles. The vetting is the value.
              </p>
            </div>

            <div className="bg-bg-card p-8 lg:p-10 rounded-3xl h-full border border-border-subtle hover:bg-bg-card-hover hover:border-brand-gold/50 transition-colors shadow-lg">
              <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">02</div>
              <h3 className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-6">Real deal flow</h3>
              <p className="text-base lg:text-lg text-text-body font-light leading-relaxed">
                When a 100B sourcing delegation closes a factory relationship, Container Club is the infrastructure that makes ongoing trade actually work. The network serves the deals.
              </p>
            </div>

            <div className="bg-bg-card p-8 lg:p-10 rounded-3xl h-full border border-border-subtle hover:bg-bg-card-hover hover:border-brand-gold/50 transition-colors shadow-lg">
              <div className="text-[48px] md:text-[56px] font-display text-gradient-gold leading-none font-medium mb-6">03</div>
              <h3 className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-6">Asia-first focus</h3>
              <p className="text-base lg:text-lg text-text-body font-light leading-relaxed">
                Built around the US-Vietnam corridor with the broader Asian trade network in view. The people in this room know how goods actually move across these borders.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 px-6 lg:px-8 text-center bg-bg-alt">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-10">
          By introduction only.<br/>
          <em className="font-serif italic text-gradient-gold">More details coming soon.</em>
        </h2>
        <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-16 max-w-3xl mx-auto">
          If you want to be on the early list when Container Club formally opens, reach out now.
        </p>
        <a href="mailto:global@100b.co" className="btn-silver-gradient inline-block rounded-full px-12 py-5 uppercase tracking-widest text-xs font-semibold mx-auto">
          global@100b.co
        </a>
      </section>
    </div>
  );
}
