import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const testimonials = [
  {
    author: "Sandy Phuong Nguyen",
    title: "FOUNDER CỎ CÂY HOA LÁ",
    description: "Rising Vietnamese wellness brand, 4.3 million products sold in 6 years since inception.",
    quote: "“When we started in 2017 with only ~3,500 USD, we never imagined selling millions of products—let alone dreaming about going global. But meeting Minh and 100B gave us courage. We dared to leave our comfort zone and dream bigger. I truly believe: TOGETHER, with 100B, we'll empower more Vietnamese brands to succeed globally.”",
    headline: "VIETNAMESE SPIRIT, GLOBAL ASPIRATION",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80",
    signatureFont: "font-serif italic"
  },
  {
    author: "Long Lu",
    title: "FOUNDER MISA",
    description: "Leading accounting software company, dominating 80%+ market share nationwide.",
    quote: "“Congratulations to Minh and the 100B team for their outstanding work in bringing Vietnamese brands and products to the global market. Your efforts are helping elevate the value of Vietnam in the eyes of the world and driving the country's development.”",
    headline: "ELEVATING VIETNAM'S GLOBAL VALUE",
    image: "https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=800&q=80",
    signatureFont: "font-serif italic"
  },
  {
    author: "Vinh Ha",
    title: "FOUNDER QUANG VINH CERAMICS",
    description: "Heritage ceramics maker, exporting to 20+ countries worldwide.",
    quote: "“Huge thanks to 100B for helping Quang Vinh Ceramics see the world with a new perspective—alongside a strong and global-minded community of Vietnamese entrepreneurs. 100B has been a launchpad and a support system, opening opportunities for our manufacturing team to access global markets. It's empowering to see Vietnamese products carried by Vietnamese founders reaching international shelves, helping build a more prosperous national economy.”",
    headline: "A LAUNCHPAD TO GLOBAL MARKETS",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=800&q=80",
    signatureFont: "font-serif italic"
  },
  {
    author: "Thang Luu",
    title: "CO-FOUNDER HEXAGON",
    description: "Top interior firm with 4 factories and 5,000+ completed projects across the globe.",
    quote: "“It's been a joy working with 100B. The direction and vision of 100B deeply aligns with Hexagon's values. We're excited for this partnership and the connections it brings. Looking forward to seeing our products in the US soon with 100B by our side.”",
    headline: "ALIGNMENT IN VISION AND VALUES",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80",
    signatureFont: "font-serif italic"
  },
  {
    author: "Thanh Dong",
    title: "CO-FOUNDER KALOTOYS",
    description: "Rising toy brand, processing up to +8,000 orders per day, 98% revenue comes from export.",
    quote: "“Born from the love of two fathers, Kalotoys has touched the hearts of millions of children and parents around the world. With 100B as a launchpad, we hope Kalotoys—and millions of other Vietnamese brands—can win the trust of global customers. As a young entrepreneur, I dream of Vietnam entering a new era, stepping confidently onto the global stage, shoulder to shoulder with any great nation.”",
    headline: "STEPPING ONTO THE GLOBAL STAGE",
    image: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?auto=format&fit=crop&w=800&q=80",
    signatureFont: "font-serif italic"
  },
  {
    author: "Nguyen Thi Huong Lien",
    title: "CO-FOUNDER SAO THÁI DƯƠNG",
    description: "Herbal care pioneer, trusted by millions with 240M+ products sold worldwide.",
    quote: "“Congratulations to 100B on such an inspiring and impactful mission for Vietnam's economic future. I send my warmest wishes to the young founders—Minh Mac, Tu Mac, Tung Cao—as they continue to build and spread this movement to Vietnamese entrepreneurs worldwide.”",
    headline: "AN INSPIRING & IMPACTFUL MISSION",
    image: "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?auto=format&fit=crop&w=800&q=80",
    signatureFont: "font-serif italic"
  }
];

export function FoundersCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-play
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handleDotClick = (index: number) => {
    setCurrentIndex(index);
  };

  return (
    <section className="py-16 md:py-24 bg-bg-dark border-t border-border-subtle relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        
        <div className="relative min-h-[500px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center"
            >
              {/* Content Side */}
              <div className="lg:col-span-7 relative">
                <div className="absolute -top-10 -left-10 text-[200px] leading-none text-border-subtle font-serif select-none pointer-events-none">
                  “
                </div>
                
                <div className="relative z-10">
                  <h3 className="text-3xl md:text-4xl lg:text-5xl font-serif text-gradient-gold mb-8 uppercase tracking-widest leading-tight">
                    "{testimonials[currentIndex].headline}"
                  </h3>
                  
                  <p className="text-base md:text-lg lg:text-xl font-light leading-relaxed text-text-body mb-12">
                    {testimonials[currentIndex].quote}
                  </p>
                  
                  <div className="mt-8 flex flex-col md:flex-row md:items-center gap-6">
                    <div className="flex-1">
                      {/* Fake signature element (cursive approximation) */}
                      <div className="font-serif italic text-4xl text-white opacity-90 mb-4" style={{ fontFamily: 'var(--font-display)', transform: 'rotate(-2deg)' }}>
                        {testimonials[currentIndex].author}
                      </div>

                      <div className="text-sm font-semibold tracking-widest text-brand-gold uppercase mb-2">
                        {testimonials[currentIndex].title}
                      </div>
                      <div className="text-xs font-light text-text-muted italic max-w-sm">
                        {testimonials[currentIndex].description}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Image Side */}
              <div className="lg:col-span-5 relative h-[400px] md:h-[500px] w-full rounded-[40px] overflow-hidden shadow-2xl border-4 border-border-subtle group ml-auto max-w-[400px]">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10 pointer-events-none"></div>
                <img 
                  src={testimonials[currentIndex].image} 
                  alt={testimonials[currentIndex].author}
                  className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 group-hover:brightness-100 transition-all duration-700 pointer-events-none"
                />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Carousel Controls */}
        <div className="flex items-center justify-center gap-4 mt-16">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => handleDotClick(index)}
              className={`transition-all duration-300 rounded-full ${
                index === currentIndex 
                  ? 'w-10 h-2 bg-brand-gold' 
                  : 'w-2 h-2 bg-border-subtle hover:bg-brand-gold/50'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
