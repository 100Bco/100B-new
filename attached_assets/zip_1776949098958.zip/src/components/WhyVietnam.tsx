import React from 'react';
import { MapPin, Handshake, Users, Factory, Scale, Globe2, CircleDollarSign, Medal } from 'lucide-react';

export function WhyVietnam() {
  const whyPoints = [
    { icon: MapPin, text: "Strategic Location" },
    { icon: Handshake, text: "Trade Agreements (EU, UK, CPTPP)" },
    { icon: Users, text: "Young, Dynamic Workforce" },
    { icon: Factory, text: "Competitive Operational Costs" },
    { icon: Scale, text: "Stable, Pro-Business Government" }
  ];

  const stats = [
    { icon: Users, value: "100M", label: "People. 70% Under 35" },
    { icon: Handshake, value: "15+", label: "Free Trade Agreements" },
    { icon: Globe2, value: "$405B", label: "In Exports" },
    { icon: CircleDollarSign, value: "$38B", label: "In FDI" },
    { icon: Medal, value: "#1", label: "Manufacturing in Southeast Asia" }
  ];

  return (
    <section className="py-16 md:py-24 bg-bg-dark border-b border-border-subtle relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-16 md:mb-20 max-w-4xl">
          Why Vietnam.<br/>
          <em className="font-serif italic text-gradient-gold">Why now?</em>
        </h2>

        {/* Top Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 mb-24 relative items-center">
          
          {/* Left Side: Globe & Subheading */}
          <div className="flex flex-col relative z-20">
            <h3 className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-6 leading-tight">
              Your smartest bet in Asia
            </h3>
            <p className="text-lg md:text-xl lg:text-2xl text-text-body font-light leading-relaxed mb-12 max-w-lg">
              Vietnam isn't the next China. It's the next Vietnam.
            </p>

            <div className="relative w-full max-w-[600px] mx-auto lg:mx-0 lg:-ml-12 mt-4">
              {/* Single Globe Image provided by User */}
              <img 
                src="/globe.png" 
                alt="Vietnam Globe"
                className="w-full h-auto object-contain drop-shadow-[0_0_80px_rgba(195,163,116,0.15)]"
              />
            </div>
          </div>

          {/* Right Side: Timeline points */}
          <div className="relative pt-8 lg:pt-0 lg:pl-10">
            {/* Vertical Line Line */}
            <div className="absolute left-[39px] lg:left-[79px] top-4 bottom-4 w-px bg-border-subtle hidden md:block"></div>

            <div className="flex flex-col gap-8 md:gap-10">
              {whyPoints.map((item, idx) => (
                <div key={idx} className="flex items-center gap-6 md:gap-8 relative z-10 group">
                  <div className="w-[52px] h-[52px] rounded-full bg-bg-card border border-border-subtle flex items-center justify-center flex-shrink-0 shadow-lg relative z-10 group-hover:border-brand-gold/50 transition-colors">
                    <item.icon size={24} className="text-brand-gold" strokeWidth={1.5} />
                  </div>
                  <div className="text-lg md:text-xl text-text-heading font-light">
                    {item.text}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Stats Card */}
        <div className="w-full">
          <div className="text-2xl lg:text-3xl font-bold font-sans text-text-heading mb-8 leading-tight">
            Stats to Highlight
          </div>
          
          <div className="bg-bg-card rounded-3xl p-8 md:p-10 lg:p-12 border border-border-subtle shadow-lg relative">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-y-12 gap-x-8">
              {stats.map((stat, idx) => (
                <div key={idx} className="flex flex-col items-center text-center group">
                  <stat.icon size={32} className="text-text-muted mb-6 group-hover:text-brand-gold transition-colors duration-500" strokeWidth={1} />
                  <div className="text-[40px] md:text-[48px] font-display text-gradient-gold leading-none font-medium mb-4">
                    {stat.value}
                  </div>
                  <div className="text-sm md:text-base text-text-body font-light leading-relaxed max-w-[150px] mx-auto">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
