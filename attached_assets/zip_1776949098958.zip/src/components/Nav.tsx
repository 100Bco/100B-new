import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (path: string) => location.pathname.startsWith(path);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 flex items-center justify-center px-6 lg:px-8 h-[88px] md:h-[96px] ${
        scrolled ? 'bg-bg-dark/90 backdrop-blur-md border-b border-border-subtle shadow-sm shadow-brand-gold/5' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 no-underline group hover:opacity-80 transition-opacity">
          <div>
            <div className="font-serif text-2xl font-normal text-text-heading tracking-wide">
              1<span className="text-brand-gold">OO</span>B
            </div>
            <div className="font-sans text-[9px] tracking-[0.3em] text-text-muted uppercase pt-0.5">
              Beyond Borders
            </div>
          </div>
        </Link>

        <div className="hidden md:flex gap-10 items-center pt-1">
          <Link 
            to="/trade" 
            className={`font-sans text-[11px] font-semibold tracking-[0.2em] uppercase transition-colors ${
              isActive('/trade') || isActive('/cc') ? 'text-brand-gold' : 'text-text-muted hover:text-white'
            }`}
          >
            Trade
          </Link>
          <Link 
            to="/build" 
            className={`font-sans text-[11px] font-semibold tracking-[0.2em] uppercase transition-colors ${
              isActive('/build') ? 'text-brand-gold' : 'text-text-muted hover:text-white'
            }`}
          >
            Build
          </Link>
          <Link 
            to="/cc" 
            className={`font-sans text-[11px] font-semibold tracking-[0.2em] uppercase transition-colors ${
              isActive('/cc') ? 'text-brand-gold' : 'text-text-muted hover:text-white'
            }`}
          >
            Container Club
          </Link>
        </div>

        <div className="flex items-center">
          <button 
            onClick={() => document.getElementById('contact-footer')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-6 py-3 md:px-8 md:py-4 btn-silver-gradient rounded-full text-[10px] md:text-xs uppercase tracking-widest font-semibold cursor-pointer"
          >
            Start a Conversation
          </button>
        </div>
      </div>
    </nav>
  );
}
