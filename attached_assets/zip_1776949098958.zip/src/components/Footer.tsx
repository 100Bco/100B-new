import React from 'react';
import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <>
      <section id="contact-footer" className="py-16 md:py-24 bg-bg-alt border-t border-border-subtle">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 flex flex-col items-center text-center">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light leading-tight mb-12 max-w-4xl text-white">
            Capital. Founders. Operators.<br/>
            <em className="font-serif italic text-gradient-gold">If that is you, let's talk.</em>
          </h2>
          <a href="mailto:global@100b.co" className="btn-silver-gradient rounded-full px-12 py-5 uppercase tracking-widest text-xs font-semibold">
            global@100b.co
          </a>
        </div>
      </section>

      <footer className="bg-bg-dark border-t border-border-subtle py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-12 lg:gap-16 text-sm font-light">
          <div>
            <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-8">100B</div>
            <div className="flex flex-col gap-4">
              <Link to="/" className="text-text-muted hover:text-white transition-colors tracking-wide">Home</Link>
              <Link to="/trade" className="text-text-muted hover:text-white transition-colors tracking-wide">Trade</Link>
              <Link to="/build" className="text-text-muted hover:text-white transition-colors tracking-wide">Build</Link>
              <Link to="/cc" className="text-text-muted hover:text-white transition-colors tracking-wide">Container Club</Link>
            </div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-8">Trade Programs</div>
            <div className="flex flex-col gap-4">
              <Link to="/trade" className="text-text-muted hover:text-white transition-colors tracking-wide">Build Better Series</Link>
              <Link to="/trade" className="text-text-muted hover:text-white transition-colors tracking-wide">Vietnam Direct 2026</Link>
              <Link to="/cc" className="text-text-muted hover:text-white transition-colors tracking-wide">Container Club</Link>
            </div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-[0.2em] font-semibold text-brand-gold mb-8">Get In Touch</div>
            <div className="flex flex-col gap-4">
              <a href="mailto:global@100b.co" className="text-text-muted hover:text-white transition-colors tracking-wide">global@100b.co</a>
              <a href="https://100b.co" className="text-text-muted hover:text-white transition-colors tracking-wide">100b.co</a>
              <div className="mt-8 text-[11px] text-text-muted tracking-[0.2em] uppercase font-semibold">Austin &middot; Ho Chi Minh &middot; Hanoi</div>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 lg:px-8 mt-20 pt-10 border-t border-border-subtle flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] text-text-muted tracking-[0.2em] uppercase font-semibold">
          <div>© 2026 100B Beyond Borders. All rights reserved.</div>
          <div>Powered by 100Bold</div>
        </div>
      </footer>
    </>
  );
}
